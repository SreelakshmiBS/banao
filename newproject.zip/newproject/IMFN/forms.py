from django import forms 
from .models import *

# class UserForm(forms.ModelForm):
#     password = forms.CharField(widget=forms.PasswordInput)
    
#     class Meta:
#         model = User
#         fields = ['name','contact','email','password']

# class EditForm(forms.ModelForm):
#     password = forms.CharField(widget=forms.PasswordInput)  

#     class Meta:
#         model = User
#         fields = ['name','contact','email','password']  

class LogincheckForm(forms.Form):
    email=forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)

class PatientForm(forms.ModelForm):
    gender_choices=(
    ('M','Male'),
    ('F','Female'),
    ('O','Other'),
    )
    gender=forms.ChoiceField(choices=gender_choices,widget=forms.RadioSelect())
    class Meta:
        model = Patient
        fields = ['name','gender','address','contact']


class LoginForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = Login
        fields = ['email','password']

class LoginEditForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['email',]


class HospitalForm(forms.ModelForm):
    district_choices = (
       ('Thiruvanathapuram','Thiruvanathapuram'),
       ('Kollam','Kollam'),
       ('Alappuzha','Alappuzha'),
       ('Pathanamthitta','Pathanamthitta'),
       ('Kottayam','Kottayam'),
       ('Idukki','Idukki'),
       ('Ernakulam','Ernakulam'),
       ('Thrissur','Thrissur'),
       ('Palakkad','Palakkad'),
       ('Malappuram','Malappuram'),
       ('Kozhikode','Kozhikode'),
       ('Wayanad','Wayanad'),
       ('Kannur','Kannur'),
       ('Kasargod','Kasargod'),
    )
    district=forms.ChoiceField(choices=district_choices,widget=forms.Select())
    class Meta:
        model = Hospital
        fields = ['name','address','district','city','contact']

class DoctorForm(forms.ModelForm):
    gender_choices=(
    ('M','Male'),
    ('F','Female'),
    ('O','Other'),
    )
    gender=forms.ChoiceField(choices=gender_choices,widget=forms.RadioSelect())
    class Meta:
        model = Doctor
        fields = ['photo','name','gender','dob','specialization','yearofexp','contact']
        widgets={
            'dob':forms.DateInput(attrs={'type':'date'})
        }
class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['appointmentdate','time']
        widgets={
            'appointmentdate':forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'}),
        }
        
        



