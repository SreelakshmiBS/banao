from django.shortcuts import render,redirect,get_object_or_404
from .forms import *
from django.contrib import messages
from .models import *

# Create your views here.

# def new(request):
#     return render(request,'new.html')

# def reg(request):
#     return render(request,'reg.html')

# def user_reg(request):
#     if request.method =='POST':
#         form=UserForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request,'User data saved successfully')
#             return redirect('user_reg')
#     else:    
#         form=UserForm()
#     return render(request,'user_reg.html',{'form':form})

# def userreg_view(request):
#     form=User.objects.all()
#     return render(request,'userreg_view.html',{'form':form})

# def user_delete(request,id):
#     user=get_object_or_404(User,id=id)
#     user.delete()
#     return redirect('userreg_view')

# def user_edit(request,id):
#     user=get_object_or_404(User,id=id)
#     if request.method=='POST':
#         form=EditForm(request.POST,instance=user)
#         if form.is_valid():
#             form.save()
#             return redirect('userreg_view')
#     else:        
#         form=EditForm(instance=user)
#     return render(request,'user_edit.html',{'form':form})  

# def login(request):
#     if request.method=='POST':
#         form=LoginForm(request.POST)
#         if form.is_valid():
#             email=form.cleaned_data['email']
#             password=form.cleaned_data['password']

#             try:
#                 user=User.objects.get(email=email)
#                 if user.password==password:
#                     request.session['user_id']=user.id
#                     return redirect('userreg_view')
#                 else:
#                     messages.error(request,'Invalid password')
#             except User.DoesNotExist:
#                 messages.error(request,'User Does Not Exist')
#     else:
#         form=LoginForm()
#     return render(request,'login.html',{'form':form})

# def logout(request):
#     request.session.flush()
#     return redirect('login')
          

# new project views

def homeindex(request):
    return render(request,'homeindex.html')

def patientindex(request):
    return render(request,'patientindex.html')

def adminindex(request):
    return render(request,'adminindex.html')

def hospitalindex(request):
    return render(request,'hospitalindex.html')

def doctorindex(request):
    return render(request,'doctorindex.html')

def ambulanceindex(request):
    return render(request,'ambulanceindex.html')

def loginindex(request):
    return render(request,'loginindex.html')

def patientreg(request):
    if request.method =='POST':
        form=PatientForm(request.POST)
        form2=LoginForm(request.POST)
        if form.is_valid() and form2.is_valid():
            var=form2.save(commit=False)
            var.usertype='patient'
            var.save()
            var2=form.save(commit=False)
            var2.login_id=var
            var2.save()
            return redirect('login')
    else:    
        form=PatientForm()
        form2=LoginForm()
    return render(request,'patient_reg.html',{'form':form,'form2':form2})

def patientreg_view(request):
    form=Patient.objects.all()
    return render(request,'patientreg_view.html',{'form':form})

def login(request):
    if request.method=='POST':
        form=LogincheckForm(request.POST)
        if form.is_valid():
            email=form.cleaned_data['email']
            password=form.cleaned_data['password']

            try:
                user=Login.objects.get(email=email)
                if user.password==password:
                    if user.usertype=='patient':
                        request.session['patient_id']=user.id
                        return redirect('patientindex')
                    elif user.usertype=='hospital':
                        request.session['hospital_id']=user.id
                        return redirect('hospitalindex')
                    elif user.usertype=='doctor':
                        request.session['doctor_id']=user.id
                        return redirect('doctorindex')
                else:
                    messages.error(request,'Invalid password')
            except user.DoesNotExist:
                messages.error(request,'User Does Not Exist')
    else:
        form=LogincheckForm()
    return render(request,'loginindex.html',{'form':form})

def logout(request):
    request.session.flush()
    return redirect('homeindex')

# def patientreg_delete(request,id):
#     patient=get_object_or_404(Patient,id=id)
#     patient.delete()
#     return redirect('patientreg_view')

def patientreg_edit(request):
    id=request.session.get('patient_id')
    patient=get_object_or_404(Patient,login_id=id)
    mail=get_object_or_404(Login,id=id)

    if request.method=='POST':
        form=PatientForm(request.POST,instance=patient)
        form2=LoginEditForm(request.POST,instance=mail)
        if form.is_valid() and form2.is_valid():
            form2.save()
            form.save()
            return redirect('patientindex')
    else:        
        form=PatientForm(instance=patient)
        form2=LoginEditForm(instance=mail)
    return render(request,'patientreg_edit.html',{'form':form,'form2':form2}) 

def hospitalreg(request):
    if request.method =='POST':
        form=HospitalForm(request.POST)
        form2=LoginForm(request.POST)
        if form.is_valid() and form2.is_valid():
            var=form2.save(commit=False)
            var.usertype='hospital'
            var.save()
            var2=form.save(commit=False)
            var2.login_id=var
            var2.save()
            return redirect('login')
    else:    
        form=HospitalForm()
        form2=LoginForm()
    return render(request,'hospital_reg.html',{'form':form,'form2':form2})

def hospitalreg_view(request):
    form=Hospital.objects.all()
    return render(request,'hospitalreg_view.html',{'form':form})

# def hospitallogin(request):
#     if request.method=='POST':
#         form=LogincheckForm(request.POST)
#         if form.is_valid():
#             email=form.cleaned_data['email']
#             password=form.cleaned_data['password']

#             try:
#                 hospital=Login.objects.get(email=email)
#                 if hospital.password==password:
#                     request.session['hospital_id']=hospital.id
#                     return redirect('hospitalindex')
#                 else:
#                     messages.error(request,'Invalid password')
#             except User.DoesNotExist:
#                 messages.error(request,'User Does Not Exist')
#     else:
#         form=LogincheckForm()
#     return render(request,'login.html',{'form':form})

def hospitalreg_edit(request):
    id=request.session.get('hospital_id')
    hospital=get_object_or_404(Hospital,login_id=id)
    mail=get_object_or_404(Login,id=id)

    if request.method=='POST':
        form=HospitalForm(request.POST,instance=hospital)
        form2=LoginEditForm(request.POST,instance=mail)
        if form.is_valid() and form2.is_valid():
            form2.save()
            form.save()
            return redirect('hospitalindex')
    else:        
        form=HospitalForm(instance=hospital)
        form2=LoginEditForm(instance=mail)
    return render(request,'hospitalreg_edit.html',{'form':form,'form2':form2}) 

def hospital_list(request):
    form=Hospital.objects.all()
    return render(request,'hospitallist_view.html',{'form':form})

def doctorreg(request):
    hospital_id=request.session.get('hospital_id')
    print("sdfghk",hospital_id)
    hos=get_object_or_404(Hospital,login_id=hospital_id)
    print ("hii",hos.id)
    if request.method =='POST':
        form=DoctorForm(request.POST,request.FILES)
        form2=LoginForm(request.POST)
        if form.is_valid() and form2.is_valid():
            var=form2.save(commit=False)
            var.usertype='doctor'
            var.save()
            var2=form.save(commit=False)
            var2.login_id=var
            print("innercall", hos.id )
            var2.hospital_id=hos
            var2.save()
            return redirect('hospitalindex')
    else:    
        form=DoctorForm()
        form2=LoginForm()
    return render(request,'doctor_reg.html',{'form':form,'form2':form2})

def doctorreg_view(request):
    form=Doctor.objects.all()
    return render(request,'doctorreg_view.html',{'form':form})

def doctorreg_edit(request):
    id=request.session.get('doctor_id')
    doctor=get_object_or_404(Doctor,login_id=id)
    mail=get_object_or_404(Login,id=id)

    if request.method=='POST':
        form=DoctorForm(request.POST,instance=doctor)
        form2=LoginEditForm(request.POST,instance=mail)
        if form.is_valid() and form2.is_valid():
            form2.save()
            form.save()
            return redirect('doctorindex')
    else:        
        form=DoctorForm(instance=doctor)
        form2=LoginEditForm(instance=mail)
    return render(request,'doctorreg_edit.html',{'form':form,'form2':form2})


def patientdoctor_view(request,hospital_id):
    form=Hospital.objects.get(id=hospital_id)
    form2=Doctor.objects.filter(hospital_id=form)
    return render(request,'doctorlist_view.html',{'form2':form2})

def makeappointment(request, doctor_id):
    doc = get_object_or_404(Doctor, id=doctor_id)
    patient_id = request.session.get('patient_id')
    pat = get_object_or_404(Patient, login_id=patient_id)
    print(pat)
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        print("hai")
        if form.is_valid():
            var = form.save(commit=False)
            var.doctor_id = doc
            var.patient_id= pat
            var.save()
            messages.success(request, "Your appointment is successfully submitted.")
            return redirect('makeappointment',doctor_id=doctor_id)
        else:
            messages.error(request, "Can't confirm your appointment! Please check your input.")
    else:
        form = AppointmentForm()
    return render(request, 'makeappointment.html', {'form': form})

def appointment_view(request):
    form = Appointment.objects.all()
    return render (request,'appointment_view.html',{'form':form})

def appointment_patient_view(request):
    id = request.session.get('patient_id')
    patient_id=Patient.objects.get(login_id=id)
    print(patient_id)
    form=Appointment.objects.filter(patient_id=patient_id)
    print(form)
    return render (request,'appointment_patient_view.html',{'form':form})

def appointment_edit(request,id):
    appointment=get_object_or_404(Appointment,id=id)
    if request.method=='POST':
        form=AppointmentForm(request.POST,instance=appointment)
        if form.is_valid():
            form.save()
            return redirect('appointment_view')
    else:        
        form=AppointmentForm(instance=appointment)
    return render(request,'appointment_edit.html',{'form':form})  

def appointment_cancel(request,id):
    appointment=get_object_or_404(Appointment,id=id)
    appointment.delete()
    return redirect('appointment_view')

def appointment_doctor_view(request):
    id = request.session.get('doctor_id')
    doctor_id=Doctor.objects.get(login_id=id)
    print(doctor_id)
    form=Appointment.objects.filter(doctor_id=doctor_id)
    return render (request,'appointment_doctor_view.html',{'form':form})




        







