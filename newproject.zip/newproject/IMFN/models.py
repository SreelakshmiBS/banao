from django.db import models

# Create your models here.

# class User(models.Model):
#     name=models.CharField(max_length=100)
#     contact=models.CharField(max_length=15)
#     email=models.EmailField(unique=True)
#     password=models.CharField(max_length=100)

class Login(models.Model):
    email=models.EmailField(unique=True)
    password=models.CharField(max_length=100)
    usertype=models.CharField(max_length=100)
    status=models.IntegerField(default=0)

class Patient(models.Model):
    login_id=models.ForeignKey(Login,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    gender=models.CharField(max_length=10)
    address=models.CharField(max_length=200)
    contact=models.CharField(max_length=15)

class Hospital(models.Model):
    login_id=models.ForeignKey(Login,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    address=models.CharField(max_length=200)
    district=models.CharField(max_length=20)
    city=models.CharField(max_length=20)
    contact=models.CharField(max_length=15)

class Doctor(models.Model):
    login_id=models.ForeignKey(Login,on_delete=models.CASCADE)
    hospital_id=models.ForeignKey(Hospital,on_delete=models.CASCADE)
    photo=models.FileField(upload_to='photo/')
    name=models.CharField(max_length=100)
    gender=models.CharField(max_length=10)
    dob=models.DateField()
    specialization=models.CharField(max_length=100)
    yearofexp=models.IntegerField()
    contact=models.CharField(max_length=15)

class Appointment(models.Model):
    doctor_id=models.ForeignKey(Doctor,on_delete=models.CASCADE)
    patient_id=models.ForeignKey(Patient,on_delete=models.CASCADE)
    appointmentdate=models.DateField()
    time=models.TimeField()
    currentdate=models.DateField(auto_now_add=True)
    



