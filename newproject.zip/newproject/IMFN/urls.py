from django.urls import path
from.import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('',views.homeindex,name='homeindex'),
    path('adminindex',views.adminindex,name='adminindex'),
    path('patientindex',views.patientindex,name='patientindex'),
    path('hospitalindex',views.hospitalindex,name='hospitalindex'),
    path('doctorindex',views.doctorindex,name='doctorindex'),
    path('ambulanceindex',views.ambulanceindex,name='ambulanceindex'),
    path('loginindex',views.loginindex,name='loginindex'),
    path('patientreg',views.patientreg,name='patientreg'),
    path('patientreg_view',views.patientreg_view,name='patientreg_view'),
    path('patientreg_edit',views.patientreg_edit,name='patientreg_edit'),
    path('login',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('hospitalreg',views.hospitalreg,name='hospitalreg'),
    path('hospitalreg_view',views.hospitalreg_view,name='hospitalreg_view'),
    # path('hospitallogin',views.hospitallogin,name='hospitallogin'
    path('hospitalreg_edit',views.hospitalreg_edit,name='hospitalreg_edit'),
    path('hospital_list',views.hospital_list,name='hospital_list'),
    path('doctorreg',views.doctorreg,name='doctorreg'),
    path('doctorreg_view',views.doctorreg_view,name='doctorreg_view'),
    path('doctorreg_edit',views.doctorreg_edit,name='doctorreg_edit'),
    path('patientdoctor_view/<int:hospital_id>/',views.patientdoctor_view,name='patientdoctor_view'),
    path('makeappointment/<int:doctor_id>/',views.makeappointment,name='makeappointment'),
    path('appointment_view',views.appointment_view,name='appointment_view'),
    path('appointment_patient_view',views.appointment_patient_view,name='appointment_patient_view'),
    path('appointment_edit/<int:id>/',views.appointment_edit,name='appointment_edit'),
    path('appointment_cancel/<int:id>/',views.appointment_cancel,name='appointment_cancel'),
    path('appointment_doctor_view',views.appointment_doctor_view,name='appointment_doctor_view'),
    
    # path('appointment_edit',views. appointment_edit,name=' appointment_edit')
    # demo
    # path('new',views.new,name='new'),
    # path('reg',views.reg,name='reg'),
    # path('user_reg',views.user_reg,name='user_reg'),
    # path('userreg_view',views.userreg_view,name='userreg_view'),
    # path('user_delete/<int:id>/',views.user_delete,name='user_delete'),
    # path('user_edit/<int:id>/',views.user_edit,name='user_edit'),
    # path('login',views.login,name='login'),
    # path('logout',views.logout,name='logout'),
    # new
    
]+ static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

